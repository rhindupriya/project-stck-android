package com.saveetha.projectstack.util

object Constance {

    const val BASE_URL = "https://m6b2nwzt-5000.inc1.devtunnels.ms/"
//    const val BASE_URL = "https://m6b2nwzt-5000.inc1.devtunnels.ms/"
}