package com.saveetha.projectstack.developer

data class TeamData(val batchId:Int, val batch:String, val startDate:String,
                    val endDate:String, val studentCount:Int, val isTeam:Boolean)
