package com.saveetha.projectstack.developer


data class TaskData(val regisrationId:String, val studentName:String, val title:String,
                    val taskName:String, val taskDate :String,val endDate:String)
