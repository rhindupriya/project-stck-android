package com.saveetha.projectstack.developer

data class ProjectData(val title:String,val studentId:String,val studentName:String,val startDate:String,
    val endDate:String,val developer:String,val projectDescription:String)


